package jp.mynavi.azurejava.sample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
